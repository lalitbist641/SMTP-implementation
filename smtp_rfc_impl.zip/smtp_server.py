# Simple RFC-like SMTP server (educational)
# Supports: HELO/EHLO, MAIL FROM, RCPT TO, DATA, RSET, NOOP, QUIT
# Listens on localhost:8025 by default.
# Save received messages to ./mailbox/*.eml
import asyncio
import datetime
import os
import re

MAILBOX_DIR = os.path.join(os.path.dirname(__file__), "mailbox")
os.makedirs(MAILBOX_DIR, exist_ok=True)

CMD_RE = re.compile(r'^(?P<cmd>[A-Za-z]+)(?:\s+(?P<arg>.*))?$')

class SMTPState:
    def __init__(self, writer):
        self.helo = None
        self.mail_from = None
        self.rcpt_to = []
        self.data_lines = []
        self.in_data = False
        self.writer = writer

async def handle_client(reader, writer):
    peer = writer.get_extra_info('peername')
    state = SMTPState(writer)
    await send_response(writer, "220 localhost Simple SMTP Service Ready")
    while True:
        line = await reader.readline()
        if not line:
            break
        line = line.decode('utf-8', 'utf-8').rstrip('\r\n')
        if state.in_data:
            # collecting DATA
            if line == ".":
                # end DATA
                state.in_data = False
                await save_message(state)
                state.mail_from = None
                state.rcpt_to = []
                state.data_lines = []
                await send_response(writer, "250 OK: queued")
            else:
                # Per RFC, lines starting with '.' are dot-stuffed; server should un-stuff here.
                if line.startswith('..'):
                    line = line[1:]
                state.data_lines.append(line)
            continue
        m = CMD_RE.match(line)
        if not m:
            await send_response(writer, "500 Syntax error, command unrecognized")
            continue
        cmd = m.group('cmd').upper()
        arg = m.group('arg') or ""
        if cmd in ("HELO", "EHLO"):
            state.helo = arg.strip()
            await send_response(writer, f"250 localhost Hello {state.helo}")
        elif cmd == "MAIL":
            # MAIL FROM:<address>
            if arg.upper().startswith("FROM:"):
                addr = arg[5:].strip()
                addr = addr.strip('<>')
                state.mail_from = addr
                state.rcpt_to = []
                await send_response(writer, "250 Sender OK")
            else:
                await send_response(writer, "501 Syntax: MAIL FROM:<address>")
        elif cmd == "RCPT":
            # RCPT TO:<address>
            if arg.upper().startswith("TO:"):
                addr = arg[3:].strip()
                addr = addr.strip('<>')
                state.rcpt_to.append(addr)
                await send_response(writer, "250 Recipient OK")
            else:
                await send_response(writer, "501 Syntax: RCPT TO:<address>")
        elif cmd == "DATA":
            if not state.mail_from or not state.rcpt_to:
                await send_response(writer, "503 Bad sequence of commands")
            else:
                state.in_data = True
                await send_response(writer, "354 End data with <CR><LF>.<CR><LF>")
        elif cmd == "RSET":
            state.mail_from = None
            state.rcpt_to = []
            state.data_lines = []
            state.in_data = False
            await send_response(writer, "250 OK")
        elif cmd == "NOOP":
            await send_response(writer, "250 OK")
        elif cmd == "QUIT":
            await send_response(writer, "221 Bye")
            break
        else:
            await send_response(writer, "502 Command not implemented")
    writer.close()
    try:
        await writer.wait_closed()
    except Exception:
        pass

async def send_response(writer, text):
    writer.write((text + "\r\n").encode('utf-8'))
    await writer.drain()

async def save_message(state: SMTPState):
    timestamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    filename = f"msg_{timestamp}_{len(os.listdir(MAILBOX_DIR))+1}.eml"
    path = os.path.join(MAILBOX_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"From: {state.mail_from}\n")
        for r in state.rcpt_to:
            f.write(f"To: {r}\n")
        f.write(f"Date: {datetime.datetime.utcnow().isoformat()}Z\n")
        f.write("\n")
        for l in state.data_lines:
            f.write(l + "\n")
    print("Saved message to", path)

def run(host="127.0.0.1", port=8025):
    print(f"Starting simple SMTP server on {host}:{port}")
    loop = asyncio.get_event_loop()
    server_coro = asyncio.start_server(handle_client, host, port)
    server = loop.run_until_complete(server_coro)
    try:
        loop.run_forever()
    except KeyboardInterrupt:
        print("Shutting down")
    server.close()
    loop.run_until_complete(server.wait_closed())
    loop.close()

if __name__ == "__main__":
    run()
