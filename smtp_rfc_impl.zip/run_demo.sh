#!/bin/bash
set -e
python3 smtp_server.py &
SERVER_PID=$!
sleep 1
python3 smtp_client.py
kill $SERVER_PID || true
