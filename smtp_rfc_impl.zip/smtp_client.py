# Simple SMTP client that speaks to the simple SMTP server above.
# Demonstrates the sequence: HELO -> MAIL FROM -> RCPT TO -> DATA -> QUIT
import socket
import sys
import time

def recvline(s):
    data = b""
    while not data.endswith(b"\r\n"):
        chunk = s.recv(1)
        if not chunk:
            break
        data += chunk
    return data.decode('utf-8', 'utf-8').strip()

def sendcmd(s, cmd):
    s.sendall((cmd + "\r\n").encode('utf-8'))
    return recvline(s)

def send_mail(server_host="127.0.0.1", server_port=8025, from_addr="alice@example.com", to_addrs=None, subject="Test", body="Hello from client!"):
    if to_addrs is None:
        to_addrs = ["bob@example.com"]
    s = socket.create_connection((server_host, server_port), timeout=10)
    print("Connected. Server says:", recvline(s))
    print(sendcmd(s, f"HELO {socket.gethostname()}"))
    print(sendcmd(s, f"MAIL FROM:<{from_addr}>"))
    for r in to_addrs:
        print(sendcmd(s, f"RCPT TO:<{r}>"))
    print(sendcmd(s, "DATA"))
    # send DATA content, end with single dot line
    s.sendall(("Subject: " + subject + "\r\n").encode('utf-8'))
    s.sendall(("\r\n").encode('utf-8'))
    for line in body.splitlines():
        # dot-stuffing: if line starts with '.', prefix another '.'
        if line.startswith('.'):
            line = '.' + line
        s.sendall((line + "\r\n").encode('utf-8'))
    s.sendall((".\r\n").encode('utf-8'))
    print(recvline(s))
    print(sendcmd(s, "QUIT"))
    s.close()

if __name__ == "__main__":
    # example usage
    send_mail()
